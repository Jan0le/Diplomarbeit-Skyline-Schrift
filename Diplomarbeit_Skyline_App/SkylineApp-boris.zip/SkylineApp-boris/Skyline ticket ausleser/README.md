Skyline Ticket Ausleser

Contents:
- `bcbp.ts` — Minimal IATA BCBP parser (boarding pass barcode)
- `flightLookupService.ts` — Optional flight times lookup via AeroDataBox (not used when manual-only)

Usage:
- Import parser in UI: `import { parseBCBP } from '../Skyline ticket ausleser/bcbp'`
- For manual-only times, let users set time pickers after scan.


