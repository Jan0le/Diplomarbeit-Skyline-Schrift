import Constants from 'expo-constants';

const cache = new Map(); // key: airline+num+date -> result

function buildKey(airlineCode, flightNumber, yyyymmdd) {
  return `${airlineCode}-${flightNumber}-${yyyymmdd}`;
}

function pickTime(seg) {
  if (!seg) return null;
  return (
    seg.scheduledTimeUtc ||
    seg.scheduledTime ||
    seg.scheduled ||
    seg.time_utc ||
    seg.time ||
    null
  );
}

function extractTimes(payload) {
  if (payload && typeof payload === 'object' && (payload.departure || payload.arrival)) {
    return {
      departureTime: pickTime(payload.departure),
      arrivalTime: pickTime(payload.arrival),
      departureActual: payload.departure?.actual || null,
      arrivalActual: payload.arrival?.actual || null,
      status: payload.flight_status || payload.status || null,
    };
  }

  const arrays = [
    Array.isArray(payload) ? payload : null,
    Array.isArray(payload?.data) ? payload.data : null,
    Array.isArray(payload?.flights) ? payload.flights : null,
    Array.isArray(payload?.results) ? payload.results : null,
    Array.isArray(payload?.items) ? payload.items : null,
  ].filter(Boolean);

  for (const arr of arrays) {
    for (const item of arr) {
      const r = extractTimes(item);
      if (r.departureTime || r.arrivalTime || r.departureActual || r.arrivalActual) return r;
    }
  }

  return { departureTime: null, arrivalTime: null, departureActual: null, arrivalActual: null, status: null };
}

async function fetchFlightApi(flightNumber, airlineCode, yyyymmdd) {
  const apiKey = Constants?.expoConfig?.extra?.flightApiKey || Constants?.manifest?.extra?.flightApiKey;
  if (!apiKey) return { departureTime: null, arrivalTime: null, departureActual: null, arrivalActual: null, status: null, extra: null };

  const url = `https://api.flightapi.io/airline/${encodeURIComponent(apiKey)}?num=${encodeURIComponent(flightNumber)}&name=${encodeURIComponent(airlineCode)}&date=${encodeURIComponent(yyyymmdd)}`;
  const resp = await fetch(url);
  if (!resp.ok) return { departureTime: null, arrivalTime: null, departureActual: null, arrivalActual: null, status: null, extra: null };
  const data = await resp.json();
  const times = extractTimes(data);
  return { ...times, extra: data ?? null };
}

function yyyymmddToIso(yyyymmdd) {
  if (!/^\d{8}$/.test(yyyymmdd)) return null;
  return `${yyyymmdd.slice(0,4)}-${yyyymmdd.slice(4,6)}-${yyyymmdd.slice(6,8)}`;
}

async function fetchAviationstackByIata(fullIata, yyyymmdd) {
  const key = Constants?.expoConfig?.extra?.aviationstackKey || Constants?.manifest?.extra?.aviationstackKey;
  if (!key) return { departureTime: null, arrivalTime: null, departureActual: null, arrivalActual: null, status: null, extra: null };
  const dateIso = yyyymmddToIso(yyyymmdd) || '';
  const url = `http://api.aviationstack.com/v1/flights?flight_iata=${encodeURIComponent(fullIata)}&flight_date=${encodeURIComponent(dateIso)}&access_key=${encodeURIComponent(key)}`;
  const resp = await fetch(url);
  if (!resp.ok) return { departureTime: null, arrivalTime: null, departureActual: null, arrivalActual: null, status: null, extra: null };
  const data = await resp.json();
  const times = extractTimes(data);
  return { ...times, extra: data ?? null };
}

async function fetchAviationstackBySplit(airlineCode, flightNumber, yyyymmdd) {
  const key = Constants?.expoConfig?.extra?.aviationstackKey || Constants?.manifest?.extra?.aviationstackKey;
  if (!key) return { departureTime: null, arrivalTime: null, departureActual: null, arrivalActual: null, status: null, extra: null };
  const dateIso = yyyymmddToIso(yyyymmdd) || '';
  const url = `http://api.aviationstack.com/v1/flights?airline_iata=${encodeURIComponent(airlineCode)}&flight_number=${encodeURIComponent(flightNumber)}&flight_date=${encodeURIComponent(dateIso)}&access_key=${encodeURIComponent(key)}`;
  const resp = await fetch(url);
  if (!resp.ok) return { departureTime: null, arrivalTime: null, departureActual: null, arrivalActual: null, status: null, extra: null };
  const data = await resp.json();
  const times = extractTimes(data);
  return { ...times, extra: data ?? null };
}

export async function getFlightTimes(flightNumber, airlineCode, dateStr /* yyyymmdd */) {
  try {
    const key = buildKey(airlineCode, flightNumber, dateStr);
    if (cache.has(key)) return cache.get(key);

    let result = await fetchFlightApi(flightNumber, airlineCode, dateStr);

    if (!result.departureTime && !result.arrivalTime) {
      const fullIata = `${airlineCode}${flightNumber}`;
      const fromIata = await fetchAviationstackByIata(fullIata, dateStr);
      if (fromIata.departureTime || fromIata.arrivalTime || fromIata.departureActual || fromIata.arrivalActual) {
        cache.set(key, fromIata);
        return fromIata;
      }
      const fromSplit = await fetchAviationstackBySplit(airlineCode, flightNumber, dateStr);
      cache.set(key, fromSplit);
      return fromSplit;
    }

    cache.set(key, result);
    return result;
  } catch {
    return { departureTime: null, arrivalTime: null, departureActual: null, arrivalActual: null, status: null, extra: null };
  }
}

export function parseFlightNumberParts(fullNumber) {
  if (!fullNumber) return { airlineCode: null, flightNumber: null };
  const airlineCode = (fullNumber.match(/[A-Z]+/gi)?.join('') || '').toUpperCase();
  const flightNumberOnly = (fullNumber.match(/\d+/g)?.join('') || '').replace(/^0+/, '') || null;
  return { airlineCode, flightNumber: flightNumberOnly };
}

export function toYYYYMMDD(dateStr) {
  if (!dateStr) return null;
  const compact = dateStr.replace(/-/g, '');
  if (/^\d{8}$/.test(compact)) return compact;
  return null;
}


